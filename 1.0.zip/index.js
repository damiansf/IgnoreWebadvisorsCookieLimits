var tabUrl = document.location.href;
	
tabUrl = tabUrl.replace('NULL', '1');

document.location.href = tabUrl;
