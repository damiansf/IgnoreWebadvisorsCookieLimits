# IgnoreWebadvisorsCookieLimits
Chrome Extension to bypass a annoying feature of the UofG's course selection website 

Available in the chrome webstore (https://chrome.google.com/webstore/detail/ignore-webadvisor-cookie/homcfondbbpefkaahogpdlhpnedngpdc)
